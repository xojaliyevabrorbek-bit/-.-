(function(){
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const LESSONS=[...new Set(VOCAB.map(v=>v.l))].sort((a,b)=>a-b);
const stripH=s=>s.replace(/[\u064B-\u065F\u0670\u0640]/g,'');
const head=s=>stripH(s.split('،')[0]).replace(/[()\s]/g,'');
const uzKey=s=>s.toLowerCase().replace(/\([^)]*\)/g,'').replace(/\s+/g,' ').trim();
const isVerb=v=>(v.ar.match(/،/g)||[]).length>=3;
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
let count=20,state=null;

// ---- sozlash ----
LESSONS.forEach(l=>{const lb=document.createElement('label');lb.innerHTML=`<input type="checkbox" value="${l}"> ${l}`;$('#lessons').append(lb);});
const selected=()=>$$('#lessons input:checked').map(i=>+i.value);
function pool(ls){ // takrorsiz so'zlar (arabcha bosh so'z yoki o'zbekcha ma'no bir xil bo'lsa — bittasi)
  const seenA=new Set(),seenU=new Set(),out=[];
  VOCAB.filter(v=>ls.includes(v.l)).forEach(v=>{const a=head(v.ar),u=uzKey(v.uz);
    if(seenA.has(a)||seenU.has(u))return;seenA.add(a);seenU.add(u);out.push(v);});
  return out;
}
function refresh(){
  const ls=selected(),n=pool(ls).length;
  const q=count==='all'?n:Math.min(count,n);
  $('#info').textContent=ls.length?`${ls.length} та дарс, ${n} та ноёб сўз. Саволлар: ${q}`+(count!=='all'&&count>n?` (сўзлар етарли эмас, шунинг учун ${n} та)`:''):'Камида битта дарс танланг.';
  $('#start').disabled=!ls.length;
}
$$('.quick button[data-r]').forEach(b=>b.onclick=()=>{
  const r=b.dataset.r;
  $$('#lessons input').forEach(i=>{const l=+i.value;
    i.checked=r==='all'?true:r==='none'?false:(()=>{const[a,z]=r.split('-').map(Number);return l>=a&&l<=z;})();});
  refresh();
});
$$('#counts button').forEach(b=>b.onclick=()=>{
  $$('#counts button').forEach(x=>x.classList.remove('on'));b.classList.add('on');
  count=b.dataset.n==='all'?'all':+b.dataset.n;refresh();
});
$('#lessons').addEventListener('change',refresh);

// ---- savol yaratish ----
function makeQuestion(item,dir,ls){
  const toUz=dir==='ar-uz';
  const key=toUz?uzKey(item.uz):head(item.ar);
  const bad=c=>c===item||head(c.ar)===head(item.ar)||uzKey(c.uz)===uzKey(item.uz);
  const tiers=[VOCAB.filter(v=>v.l===item.l),VOCAB.filter(v=>ls.includes(v.l)),VOCAB];
  const picked=[],used=new Set([key]);
  for(const t of tiers){
    let c=shuffle(t.filter(v=>!bad(v)));
    c.sort((a,b)=>(isVerb(a)===isVerb(item)?0:1)-(isVerb(b)===isVerb(item)?0:1)); // bir turdagi so'zlar oldin
    for(const v of c){
      if(picked.length>=3)break;
      const k=toUz?uzKey(v.uz):head(v.ar);
      if(used.has(k))continue;
      used.add(k);picked.push(v);
    }
    if(picked.length>=3)break;
  }
  const opts=shuffle([item,...picked]).map(v=>({text:toUz?v.uz:v.ar,ok:v===item}));
  return{item,dir,opts};
}
function buildTest(items,dirMode,ls){
  return shuffle(items).map(it=>makeQuestion(it,dirMode==='mix'?(Math.random()<.5?'ar-uz':'uz-ar'):dirMode,ls));
}
function start(items,ls,dirMode){
  state={qs:buildTest(items,dirMode,ls),i:0,wrong:[],ok:0,ls,dirMode};
  $('#setup').hidden=true;$('#result').hidden=true;$('#quiz').hidden=false;show();
}

// ---- test ----
function show(){
  const q=state.qs[state.i],n=state.qs.length;
  $('#progress').textContent=`${state.i+1} / ${n}`;
  $('#fill').style.width=(state.i/n*100)+'%';
  const toUz=q.dir==='ar-uz';
  $('#qlabel').textContent=toUz?'Ўзбекчасини топинг':'Арабчасини топинг';
  const t=$('#qtext');t.textContent=toUz?q.item.ar:q.item.uz;t.className='qtext'+(toUz?' ar':'');
  const box=$('#options');box.innerHTML='';
  q.opts.forEach((o,k)=>{const b=document.createElement('button');
    b.className='opt'+(toUz?'':' ar');b.textContent=o.text;b.onclick=()=>answer(k);box.append(b);});
  $('#next').hidden=true;q.done=false;
}
function answer(k){
  const q=state.qs[state.i];if(q.done)return;q.done=true;q.picked=k;
  const bs=$$('.opt');
  bs.forEach((b,j)=>{b.disabled=true;if(q.opts[j].ok)b.classList.add('ok');});
  if(q.opts[k].ok)state.ok++;else{bs[k].classList.add('bad');state.wrong.push(q);}
  const last=state.i===state.qs.length-1;
  $('#next').textContent=last?'Натижани кўриш':'Кейингиси';$('#next').hidden=false;$('#next').focus();
}
$('#next').onclick=()=>{if(state.i<state.qs.length-1){state.i++;show();}else finish();};
$('#quit').onclick=()=>{if(confirm('Тестни тугатамизми? Жавоб берилмаган саволлар хато ҳисобланмайди.')){state.qs=state.qs.slice(0,state.i+(state.qs[state.i].done?1:0));if(!state.qs.length){back();return;}finish();}};
document.addEventListener('keydown',e=>{
  if($('#quiz').hidden)return;
  if(/^[1-4]$/.test(e.key))answer(+e.key-1);
  else if(e.key==='Enter'&&!$('#next').hidden)$('#next').click();
});

// ---- natija ----
function finish(){
  const n=state.qs.length,ok=state.ok,pc=Math.round(ok/n*100);
  $('#quiz').hidden=true;$('#result').hidden=false;
  $('#sc').textContent=`${ok} / ${n}`;$('#pc').textContent=pc+'%';
  $('#detail').textContent=`Жами: ${n}. Тўғри: ${ok}. Нотўғри: ${n-ok}.`;
  const w=state.wrong;
  $('#wrongTitle').hidden=!w.length;$('#retryWrong').hidden=!w.length;
  const L=$('#wrongList');L.innerHTML='';
  w.forEach(q=>{
    const toUz=q.dir==='ar-uz',d=document.createElement('div');d.className='w';
    const right=q.opts.find(o=>o.ok).text,mine=q.opts[q.picked].text,cls=toUz?'':' ar';
    const qt=document.createElement('div');qt.className='q'+(toUz?' ar':'');qt.textContent=(toUz?q.item.ar:q.item.uz);
    const a1=document.createElement('div');a1.className='a badt';a1.append('Сизнинг жавобингиз: ');const s1=document.createElement('span');s1.className=cls.trim();s1.textContent=mine;a1.append(s1);
    const a2=document.createElement('div');a2.className='a good';a2.append('Тўғри жавоб: ');const s2=document.createElement('span');s2.className=cls.trim();s2.textContent=right;a2.append(s2);
    const m=document.createElement('div');m.className='m';m.textContent=`${q.item.l}-дарс`+(q.item.check?' · арабча ҳаракатлари қайта текширилиши керак':'');
    d.append(qt,a1,a2,m);L.append(d);
  });
}
function back(){$('#quiz').hidden=true;$('#result').hidden=true;$('#setup').hidden=false;refresh();}
$('#again').onclick=back;
$('#retryWrong').onclick=()=>start(state.wrong.map(q=>q.item),state.ls,state.dirMode);
$('#start').onclick=()=>{
  const ls=selected(),p=pool(ls);if(!p.length)return;
  const n=count==='all'?p.length:Math.min(count,p.length);
  const dirMode=document.querySelector('input[name=dir]:checked').value;
  start(shuffle(p).slice(0,n),ls,dirMode);
};
$$('#lessons input').slice(0,1).forEach(i=>i.checked=true);refresh();
})();
